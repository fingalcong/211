#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define EXP_SZ 8
#define FRAC_SZ 23

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }


    char buff;
    unsigned int binary = 0;
    int sign;
    for (int i=EXP_SZ+FRAC_SZ; 0<=i; i--) {
        fscanf(fp,"%c",&buff);
        if(i==EXP_SZ+FRAC_SZ){
            sign = buff-'0';
        }
        else {
            if(buff != '\0'){
                binary <<= 1;
                binary += buff-'0';
              }
              else if (buff != '\0'){
              }
              else{
                break;
                  }
              }
        }
    unsigned int e= binary;
    int i = EXP_SZ+FRAC_SZ-1;
    while(i>=EXP_SZ){
        e>>=1;
        i--;
    }
    e= e-127;

    unsigned int Exp = 1;
    unsigned int temp = binary;
    int x = 0;
    int y = 0;
    while(x<EXP_SZ){
        temp <<=1;
        x++;
    }
    while(y<EXP_SZ){
        temp >>=1;
        y++;
    }

    double num=0;
    for (int digit = 0,ex=(-1*(FRAC_SZ)); digit<FRAC_SZ; digit++,ex++ ) {
        int val = 0b1 & temp>>digit;
        num = num+ ldexp ( val, ex );
    }

    double m = Exp+num;

    double number = ldexp ( m, e);
    number = sign ? -number : number;
    printf("%e", number);

    return EXIT_SUCCESS;

}
