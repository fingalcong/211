#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
void printHex(int value){
    if (value < 10) {
        printf("%c",value+48);
    }
    else {
        printf("%c",value+55);
    }

}

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // first, read the number
    signed short int input;
    fscanf(fp, "%hd", &input); // note how the 'h' modifier shortens the %d to half size
    int* memory = malloc(16*sizeof(int));
    int x =15;
    int t = 0;
    int y = 3;

    // print bits; you will see this kind of for loop often in this assignment
    for ( int digit=16; 0<=digit; digit-- ) {
        bool char_val = 0b1 & input>>digit; // shift and mask
        if(digit != 16){
            memory[digit] = char_val;
        }
        else {
          continue;
        }
    }

    while (x >=0){
        if( memory[x] ==1){
            t = t+pow(2,y);
        }
        y--;
        if (y == -1){
            printHex(t);
            t = 0;
            y = 3;
        }
        x--;
    }
    free(memory);

    return EXIT_SUCCESS;
}
