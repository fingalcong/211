#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#define EXP_SZ 8
#define FRAC_SZ 23
#define BIAS 127

unsigned int FunctionA(double b){
    unsigned int val =0>>(FRAC_SZ-1);
    for(int i = FRAC_SZ-1; i>=0; i--){
        bool temp = (int)(b*2);
        b = b*2 - ((int)temp);

        if(temp == true){
            val |= (int)1<<i;
        }
        else{
          continue;
        }
    }
    return val;
}

double FunctionB(unsigned int a){
    double val = 0;
    for(int i = FRAC_SZ-1;i>=0; i--){
        int c = 0b1 & a>>i;
        val+= ldexp(c,i-(FRAC_SZ));
    }
    return val+=1;
}


int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    char buff;
    unsigned int num1 = 0;
    int i=EXP_SZ+FRAC_SZ;
    while(i>=0){
        fscanf(fp,"%c",&buff);
        if(buff != '\0'){
            num1 <<= 1;
            num1 += buff-'0';
        }
        else{
          continue;
        }
        i--;
    }

    char buf;
    unsigned int num2 = 0;
    int x=EXP_SZ+FRAC_SZ+1;
    while(x>=0){
        fscanf(fp,"%c",&buf);
        if(buf != '\0'){
            num2 <<= 1;
            num2 += buf-'0';
        }
        else{
          continue;
        }
        x--;
    }

    int sign1 = 0b1 & num1>>(EXP_SZ+FRAC_SZ);
    int sign2 = 0b1 & num2>>(EXP_SZ+FRAC_SZ);
    int sign = sign1 ^ sign2;

    printf("%d_",sign);

    unsigned int exp1 = (num1<<1)>>(FRAC_SZ+1);
    unsigned int exp2 = (num2<<1)>>(FRAC_SZ+1);
    unsigned int exp = exp1+exp2;
    exp= exp - BIAS;

    unsigned int lier = (num1<<(EXP_SZ+1));
    unsigned int elem = (num2<<(EXP_SZ+1));

    lier >>= EXP_SZ+1;
    elem >>= EXP_SZ+1;
    double liar = FunctionB(lier);
    double element = FunctionB(elem);

    float product = liar*element;

    unsigned int num = (int) product;
    double deci = product - num;
    unsigned int frac = FunctionA(deci);
    while(num>=2.0){
        num = num /2.0;
        exp+=1;
        frac>>=1;
    }

    int bit_index=EXP_SZ-1;
    while(0<=bit_index){
        bool trial_bit = 1&exp>>bit_index;
        printf("%d",trial_bit);
        bit_index--;
    }
    printf("_");

    for ( int bit_index=FRAC_SZ-1; 0<=bit_index; bit_index-- ) {
        bool trial_bit = 1&frac>>bit_index;
        printf("%d",trial_bit);
    }
    return(EXIT_SUCCESS);
}
