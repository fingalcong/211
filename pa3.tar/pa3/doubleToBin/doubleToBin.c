#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#define EXP_SZ 11
#define FRAC_SZ 52

int main(int argc, char *argv[]) {
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return 0;
    }

    double value;
    fscanf(fp, "%lf", &value);
    unsigned long int ref_bits = *(unsigned long int*) &value;

    bool sign = value<0.0;
    printf("%d_",sign);
    assert (sign == (1&ref_bits>>(EXP_SZ+FRAC_SZ)));

    double fraction = sign ? -value : value;
    signed short trial_exp=(1<<(EXP_SZ-1))-1;

    if(1.0<= fraction && fraction<2.0) {
      trial_exp = 0;
    }
    else{
        for(int i = trial_exp;i >=(-1023); i--){
                double temp = ldexp(fraction,i);
                double temp2 = ldexp(fraction,i-1);

                if(1.0<= temp && temp <=2.0 ){
                    if(1.0<=temp2 && temp2 <2.0){
                    }
                    else{
                        trial_exp = i;
                        break;
                    }
                }
                else{
                  continue;
                }
        }
    }


    unsigned short bias = (1<<(EXP_SZ-1))-1;
    signed short exp =  bias - trial_exp;
    int exp_index=EXP_SZ-1;
    while(exp_index>=0) {
        bool exp_bit = 1&exp>>exp_index;
        printf("%d",exp_bit);
        exp_index--;
    }
    printf("_");

    bool frac_array[FRAC_SZ+1];
    int t = (int)fraction;
    double c = fraction-t;
    int idx = (-trial_exp);
    int frac_index=FRAC_SZ;

    while(0<=frac_index){
        if(idx>0){
            frac_array[frac_index] = 0b1 & t>>(idx);
            idx--;
        }
        else{
            bool temp = (int)c&&2;
            c = c*2 - ((int)c*2);
            if(temp!=0){
                frac_array[frac_index] = true;
            }
            else{
                frac_array[frac_index] = false;
            }
        }
        frac_index--;
    }

    bool temp_array[FRAC_SZ+1];
    int i = FRAC_SZ;
    while(i>=0){
        temp_array[i] = false;
        i--;
    }
    int dex = FRAC_SZ;
    bool correctness =false;
    for ( int frac_index=FRAC_SZ; 0<=frac_index; frac_index-- ) {
        if(correctness == true){
            temp_array[dex] = frac_array[frac_index];
            dex--;
        }
        else{
            if(frac_array[frac_index] == true){
                correctness = true;
            }
            else{
              continue;
            }
        }
    }


    for ( int frac_index=FRAC_SZ-1; 0<=frac_index; frac_index-- ) {
        bool frac_bit = temp_array[frac_index+1];
        printf("%d", frac_bit);
    }
}
