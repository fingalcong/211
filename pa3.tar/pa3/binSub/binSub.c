#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    char buff[9];
    fscanf(fp, "%s\n", buff);

    bool minuend[8]; // suggested that you store bits as array of bools; minuend[0] is the LSB
    for (int i=7,j=0; 0<=i; i--,j++) { // read MSB first as that is what comes first in the file

        if(buff[j] != '1'){
            minuend[i]= 0;
        }
        else{
            minuend[i]= 1;
        }

    }

    fscanf(fp, "%s\n", buff);
    bool subtrahend[8]; // suggested that you store bits as array of bools; subtrahend[0] is the LSB
    for (int i=7,j=0; 0<=i; i--,j++) { // read MSB first as that is what comes first in the file

        if(buff[j] != '1'){
            subtrahend[i]= 0;
        }
        else{
            subtrahend[i]= 1;
        }

    }
    int i = 7;
    while(i>=0){
        if(subtrahend[i] != 0){
            subtrahend[i]= 0;
        }
        else{
            subtrahend[i]= 1;
        }
        i--;
    }

    bool carry = true;
    int x = 0;
    while(x<8){
        if(carry == true){
            if(subtrahend[x] !=1){
                subtrahend[x] =1;
                carry = false;
            }
            else{
                subtrahend[x] =0;
            }
        }
        else{
          break;
        }
        x++;
    }
    bool difference[8];
    bool bit = false;
    int y = 0;

        while(y<8){
        difference[y] = minuend[y]^subtrahend[y]^bit;
        if(minuend[y]+subtrahend[y]+bit > 1){
            bit = true;
        }
        else{
            bit = false;
        }
     y++;
    }

    for (int i=7; 0<=i; i--)
        printf("%d",difference[i]);

    return EXIT_SUCCESS;

}
