#include "../graphutils.h"
bool DFS(size_t Value, AdjacencyListNode* adjacencyList,bool* visited,graphNode_t source){
    visited[source] = true;

    AdjacencyListNode* closePoint = adjacencyList[source].next;

    while(closePoint == NULL){
      break;
    }
    while(closePoint != NULL){
      if(visited[(*closePoint).graphNode] == true){
              printf("%ld %ld ",(*closePoint).graphNode,source);
              //tried using array to store the numbers that have been visited, but it didn't work
              //Also, i had trouble printing the array out
              return true;
      }
        else if (visited[(*closePoint).graphNode] == false){

            if (DFS(Value, adjacencyList,visited,(*closePoint).graphNode) == true){
                return true;
            }
            else{
              // we do not need to make change on the code
            }
        }
        closePoint= (*closePoint).next;
    }
    visited[source] = false;
    return false;
}

int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList;
    int Value = adjMatrixToList(argv[1], &adjacencyList);
    /* ... */


    bool* visited = malloc (Value * sizeof(bool));
    int m =0;
    while(m < Value){
        visited[m] = false;
        m++;
    }

    for (unsigned source=0; source<Value; source++) {
        /* ... */
        if (visited[source] == true){
          //we do nothing on the code
        }
        else if(visited[source] == false){
            bool correctness = DFS(Value,adjacencyList, visited, source);
            if(correctness == true){
                break;
            }
            else if (correctness == false){
              //break;
            }
        }
    }

    free(visited);

    freeAdjList ( Value, adjacencyList );
    return EXIT_SUCCESS;
}
