#include "../graphutils.h" // header for functions to load and free adjacencyList
void read(size_t num,AdjacencyListNode* array){
    int i = 0;
    while(i < num){
        AdjacencyListNode* closepoint = array[i].next;
        while (closepoint ==NULL){
          break;
        }
        while(closepoint != NULL){
          if ((*closepoint).graphNode < i){
            //we do not do anything here, or it will have a duplicate
          }
          else if ((*closepoint).graphNode == i){
            //we do not do anything here, or it will have a duplicate
          }
            else{
                printf("%d %ld\n",i,(*closepoint).graphNode);
            }
            closepoint = (*closepoint).next;
        }
     i++;
    }

}
int main ( int argc, char* argv[] ) {

    // FIRST, READ THE ADJACENCY MATRIX FILE
    AdjacencyListNode* array = NULL;
    int num = adjMatrixToList ( argv[1], &array);

    read(num,array);
    freeAdjList(num,array);

    return EXIT_SUCCESS;
}
