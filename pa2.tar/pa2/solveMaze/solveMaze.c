#include "../graphutils.h" // header for functions to load and free adjacencyList

// A program to solve a maze that may contain cycles using BFS

// BFS requires using a queue data structure
typedef struct QueueNode {
    graphNode_t graphNode;
    struct QueueNode* next;
} QueueNode;

struct Queue {
    struct QueueNode* front; // front (head) of the queue
    struct QueueNode* back; // back (tail) of the queue
};
typedef struct Queue Queue;

// Append a new QueueNode to the back of the Queue
struct Queue enqueue ( struct Queue queue, graphNode_t graphNode ) {
  QueueNode* x = malloc(sizeof(QueueNode));
  (*x).graphNode = graphNode;
  (*x).next= NULL;
    if(queue.back !=NULL && queue.front != NULL){
      (*queue.back).next = x;
      queue.back = x;
    }
    else{
        queue.back =x;
        queue.front = x;
    }
    return queue;
}
// Remove a QueueNode from the front of the Queue
graphNode_t dequeue ( Queue* queue ) {
  graphNode_t value;
  QueueNode* t = (*queue).front;
  value = (*t).graphNode;
    if((*queue).back != (*queue).front){
      QueueNode* next = (*t).next;
      (*queue).front = next;
    }
    else{
      (*queue).back = NULL;
      (*queue).front = NULL;
    }
    free(t);
    return value;
}

int main ( int argc, char* argv[] ) {

    AdjacencyListNode* adjacencyList = NULL;

    // USE A QUEUE TO PERFORM BFS
    Queue queue = { .front=NULL, .back=NULL };
    int num = adjMatrixToList (argv[1], &adjacencyList);

    // An array that keeps track of who is the parent node of each graph node we visit
    graphNode_t* parents = calloc( num, sizeof(graphNode_t) );
    for (size_t i=0; i<num; i++) {
        parents[i] = -1; // -1 indicates that a nodes is not yet visited
    }

    int data;
    int target;
    FILE *fp = fopen(argv[2], "r");

    if (fp == NULL){
      return(0);
    }

    fscanf(fp,"%d\n",&data);
    fscanf(fp,"%d\n",&target);
    /* ... */

    while ( data != target ) {

            queue = enqueue(queue,data);
            Queue* number = &queue;
            data = dequeue(number);
            parents[data] =1;
            AdjacencyListNode* closePoint = adjacencyList[data].next;
            while(closePoint == NULL){
              break;
            }
            while(closePoint != NULL){
                if(parents[(*closePoint).graphNode] == 1){
                  //which means  that the point has been visited
                }
                else if(parents[(*closePoint).graphNode] == -1){
                    parents[(*closePoint).graphNode] =1;
                    queue = enqueue(queue, (*closePoint).graphNode);
                    printf("%d %ld\n",data,(*closePoint).graphNode);
}
                closePoint= (*closePoint).next;
            }

    }


    // free any queued graph nodes that we never visited because we already solved the maze
    while ( queue.front ) {
        dequeue(&queue);
    }
    free (parents);
    freeAdjList ( num, adjacencyList );
    fclose(fp);

    return EXIT_SUCCESS;
}
